# Synthetic fixture: synthetic-scanned.pdf

Alpha revenue 120; Beta revenue 240.

<table><tr><th>Item</th><th>Revenue</th></tr><tr><td>Alpha</td><td>120</td></tr><tr><td>Beta</td><td>240</td></tr></table>

![Synthetic chart](images/figure.png)
